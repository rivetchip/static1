<?php


set_time_limit(10);


$config = array(
    'driver'   => 'mysql',
    'host'     => 'localhost',
    'database' => 'todolist',
    'username' => 'root',
    'password' => 'helloworld',
    'charset'  => 'utf8' // utf8mb4
);

$table = 'crm_mail_types';

$attachmentFolder = getcwd() . '/attachments/';



// cannot use emojis unicode 😃 😺 ( 4 bytes ) in mysql utf8 
// ( permits only the unicode characters that can be represented with 3 bytes )
// mysql >= 5.5 : convert utf8 to utf8mb4

$options = array(
    PDO::ATTR_CASE => PDO::CASE_NATURAL,
    PDO::ATTR_ORACLE_NULLS => PDO::NULL_NATURAL,
    PDO::ATTR_STRINGIFY_FETCHES => false,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_OBJ,
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_EMULATE_PREPARES => false,

    //PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8mb4'
);

// PDO connection

$dsn = sprintf('%s:host=%s;dbname=%s', $config['driver'], $config['host'], $config['database']); //;charset=

$pdo = new PDO($dsn, $config['username'], $config['password'], $options); // todo try-catch

if( !empty($config['charset']) )
{
    $pdo->exec('SET NAMES ' . $config['charset']);
}




function response( $datas )
{
    header('Content-type:application/json;charset=utf-8', true);

    die(json_encode($datas));
}



if( isset($_GET['populateList']) )
{

    $statement = $pdo->prepare('SELECT type, id, title, color, deleted FROM '.$table.' ORDER BY position ASC');

    $statement->execute();

    $result = $statement->fetchAll();


    return response($result);
}



if( isset($_GET['getCategory'], $_GET['categoryId']) )
{

    $id = $_GET['categoryId'];


    $statement = $pdo->prepare('SELECT * FROM '.$table.' WHERE type = :type AND id = :id');

    $statement->execute(array(
        'type' => 'mail',
        'id'   => $id
    ));

    $result = $statement->fetch();


    return response($result);
}




if( isset($_GET['createCategory'], $_GET['categoryTitle']) )
{

    $title = $_GET['categoryTitle'];


    // get max(position)

    $position = 0;

    $query = $pdo->query('SELECT MAX(position) as position FROM '.$table.'')->fetch();

    if( !empty($query->position) )
    {
        $position = $query->position;
    }

    $position++;


    // insert

    $statement = $pdo->prepare('INSERT INTO '.$table.'(type, title, position) VALUES(:type, :title, :position)');

    $statement->execute(array(
        'type'     => 'mail',
        'title'    => $title,
        'position' => $position

        //'time'  => time()
    ));

    $id = $pdo->lastInsertId();

    $deleted = 0; // default open/close


    return response(array(
        'id'      => $id,
        'title'   => $title,
        'deleted' => $deleted,
    ));
}




if( isset($_GET['createLine']) )
{

    $title = '-----';


    // get max(position)

    $position = 0;

    $query = $pdo->query('SELECT MAX(position) as position FROM '.$table.'')->fetch();

    if( !empty($query->position) )
    {
        $position = $query->position;
    }

    $position++;


    // insert

    $statement = $pdo->prepare('INSERT INTO '.$table.'(type, title, position) VALUES(:type, :title, :position)');

    $statement->execute(array(
        'type'     => 'line',
        'title'    => $title,
        'position' => $position
    ));

    $id = $pdo->lastInsertId();


    return response(array(
        'id'    => $id,
        'title' => $title
    ));
}




if( isset($_GET['updateCategory'], $_GET['categoryId']) )
{

    $id = $_GET['categoryId'];

    $datas = file_get_contents('php://input');

    if( !empty($datas) )
    {
        $datas = json_decode($datas);


        $field = $datas->field; // FIXME security!

        $value = $datas->value;


        $statement = $pdo->prepare('UPDATE '.$table.' SET '.$field.' = :value WHERE type = :type AND id = :id');

        $statement->execute(array(
            'type'  => 'mail',
            'id'    => $id,
            'value' => $value
        ));
    }


    // time is automatically updated by the DB engine


    return response(array('message'=>'ok'));
}



if( isset($_GET['openCategory'], $_GET['categoryId']) )
{

    $id = $_GET['categoryId'];


    $statement = $pdo->prepare('UPDATE '.$table.' SET deleted = "0" WHERE type = :type AND id = :id');

    $statement->execute(array(
        'type' => 'mail',
        'id'   => $id
    ));


    return response(array('message'=>'ok'));
}



if( isset($_GET['deleteCategory'], $_GET['categoryId']) )
{

    $id = $_GET['categoryId'];


    $statement = $pdo->prepare('UPDATE '.$table.' SET deleted = "1" WHERE type = :type AND id = :id');

    $statement->execute(array(
        'type' => 'mail',
        'id'   => $id
    ));


    return response(array('message'=>'ok'));
}



if( isset($_GET['deleteLine'], $_GET['lineId']) )
{

    $id = $_GET['lineId'];


    $statement = $pdo->prepare('DELETE FROM '.$table.' WHERE type = :type AND id = :id');

    $statement->execute(array(
        'type' => 'line',
        'id'   => $id
    ));


    return response(array('message'=>'ok'));
}



// update the orders, mail or line

if( isset($_GET['updateOrder']) )
{

    $datas = file_get_contents('php://input');

    if( !empty($datas) )
    {
        $datas = json_decode($datas);


        $statement = $pdo->prepare('UPDATE '.$table.' SET position = :position WHERE id = :id');

        foreach( $datas as $id => $position )
        {
            $statement->execute(array(
                //'type'     => 'mail',
                'id'       => $id,
                'position' => $position
            ));
        }
    }


    return response(array('message'=>'ok'));
}






// rogue attachments modal


// get attachements files

if( isset($_GET['populateFileList']) )
{
    $files = scandir($attachmentFolder);

    $filesNames = array();

    if( $files !== false )
    {
        $files = array_diff($files, array('..', '.'));

        foreach( $files as $fileName )
        {
            $fileType = mime_content_type($attachmentFolder . $fileName);

            $fileSize = filesize($attachmentFolder . $fileName);

            $filesNames[] = array(
                'name' => $fileName,
                'type' => $fileType,
                'size' => $fileSize
            );
        }

        // send

        return response($filesNames);
    }
    else
    {
        throw new RuntimeException('Cannot get files');
    }

}



// TODO http://php.net/manual/fr/features.file-upload.php

// upload_max_filesize = 2M
// max_file_uploads = 20
// post_max_size >= upload_max_filesize

// FIXME SECURITY, CAN UPLOAD / DELETE ANYTHING



if( isset($_GET['fileUpload']) )
{
    function fileName( $name )
    {
        $name = str_replace(array(' ', '_', '/', '\\'), '-', $name);

        $name = strtr($name,
            '@ÀÁÂÃÄÅÇÈÉÊËÌÍÎÏÒÓÔÕÖÙÚÛÜÝàáâãäåçèéêëìíîïðòóôõöùúûüýÿ',
            'aAAAAAACEEEEIIIIOOOOOUUUUYaaaaaaceeeeiiiioooooouuuuyy'
        );

        return $name;
    }

    try {

        if( !is_writable($attachmentFolder) )
        {
            throw new RuntimeException('Folder is not writable');
        }


        // curent files sended by the request

        $files = array();

        $filesNames = array();


        if( !empty($_FILES['files']) )
        {
            $vector = $_FILES['files'];

            // first filter

            foreach( array('name', 'type', 'tmp_name', 'error', 'size') as $attr )
            {
                foreach( $vector[$attr] as $key => $value )
                {
                    $files[$key][$attr] = $value;
                }
            }

            // check for php errors

            foreach( $files as $key => $file )
            {

                // check $_FILES['upfile']['error'] value

                switch( $file['error'] )
                {
                    case UPLOAD_ERR_OK: // 0
                        break;

                    case UPLOAD_ERR_INI_SIZE: // 1
                    case UPLOAD_ERR_FORM_SIZE: // 2
                        throw new RuntimeException('Exceeded filesize limit');

                    case UPLOAD_ERR_PARTIAL: // 3
                        throw new RuntimeException('File was only partially uploaded');
                    
                    case UPLOAD_ERR_NO_FILE: // 4
                        throw new RuntimeException('No file sent');

                    case  UPLOAD_ERR_NO_TMP_DIR: // 6
                        throw new RuntimeException('Cannot find tmp');
                    
                    case  UPLOAD_ERR_CANT_WRITE: // 7
                        throw new RuntimeException('Failed to write file to disk tmp');


                    default:
                        throw new RuntimeException('Unknown errors');
                }

                // Check MIME Type by yourself

                // $finfo = new finfo(FILEINFO_MIME_TYPE);

                // if( false === $ext = array_search(
                //     $finfo->file($_FILES['upfile']['tmp_name']),
                //     array(
                //         'jpg' => 'image/jpeg',
                //         'png' => 'image/png',
                //         'gif' => 'image/gif',
                //     ),
                //     true
                // ) )
                // {
                //     throw new RuntimeException('Invalid file format.');
                // }

                // You should name it uniquely
                // if( !move_uploaded_file($_FILES['upfile']['tmp_name'], sprintf('./uploads/%s.%s', sha1_file($_FILES['upfile']['tmp_name']), $ext)) )

                // FIXME: security!


                $tmpName  = $file['tmp_name'];
                $fileName = fileName($file['name']);
                
                if( !move_uploaded_file($tmpName, $attachmentFolder . $fileName) )
                {
                    throw new RuntimeException('Failed to move uploaded file');
                }

                // prepare the file list to be send via ajax

                $fileType = mime_content_type($attachmentFolder . $fileName);

                $fileSize = filesize($attachmentFolder . $fileName);

                // chmod the file to be readable by everyone

                chmod($attachmentFolder . $fileName, 0775);


                $filesNames[] = array(
                    'name' => $fileName,
                    'type' => $fileType,
                    'size' => $fileSize
                );

            }


        } // !empty files
    

    }
    catch( RuntimeException $e )
    {
        // return the exception

        return response(array('error'=> $e->getMessage()));
    }


    return response(array('message'=> 'ok', 'files' => $filesNames));
}



if( isset($_GET['fileDelete'], $_GET['fileName']) )
{

    $fileName = $_GET['fileName'];


    try {

        // check file exist, before delete it

        if( !file_exists($attachmentFolder . $fileName) )
        {
            throw new RuntimeException('File does not exist');
        }


        // remove attachment from categories that depend on the file

        $statement = $pdo->prepare('UPDATE '.$table.' SET attachment = :value WHERE type = :type AND attachment = :filename');

        $statement->execute(array(
            'type'     => 'mail',
            'filename' => $fileName,
            'value'    => ''         // new value
        ));


        // finally, delete the file

        if( !unlink($attachmentFolder . $fileName) )
        {
            throw new RuntimeException('Failed to delete the file');
        }

    }
    catch( RuntimeException $e )
    {
        // return the exception

        return response(array('error'=> $e->getMessage()));
    }



    return response(array('message'=> 'ok'));
}

