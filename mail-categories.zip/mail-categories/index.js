"use strict";


var api = 'api.php';

var timeoutDuration = 1500; // modal editor

var colors = ['blank', 'turquoise', 'emerald', 'peterriver', 'amethyst', 'wetasphalt', 'sunflower', 'carrot', 'alizarin', 'concrete', 'clouds'];



if( /^((?!chrome|android).)*safari/i.test(navigator.userAgent) )
{
    // safari specific :
}


//document.DOMContentLoaded

window.addEventListener('load', function( event ) {

    // global error, after the load, when uncaught throwed exceptions

    window.addEventListener('error', function( event )
    {
        var message = event.message + ' - l' + event.lineno;

        error(message, 'window');

        return false;
    });

    // first loader

    var loader = document.getElementById('loader');

    // categories

    var categoryButton = document.getElementById('category-button');

    var categoryInput = document.getElementById('category-input');

    categoryButton.addEventListener('click', onCategoryCreate);


    var lineButton = document.getElementById('line-button');

    lineButton.addEventListener('click', onLineCreate);
    
    // lsit of tiems

    var categoryList = document.getElementById('category-list');

    // current drag drop item.draggable

    var currentDragElement;

    // modal editor

    var timeoutKeyupField = {}; // multiples timeout, user could edit others inputs in less than the time limit

    var modalEditor = document.getElementById('modalEditor');

    var modalEditorContent = modalEditor.querySelector('.modal-content');

    var modalEditorClose = modalEditor.querySelector('.modal-close');

    modalEditorClose.addEventListener('click', onModalClose);

    modalEditor.addEventListener('click', function( event ) // click outsie modal-dialog ( window )
    {
        if( event.target == this ) onModalClose(event);
    });

    // modal wysiwyg editor

    var editor = document.getElementById('editor');

    var editorMenu = createEditorMenu();

    editorMenu.setAttribute('id', 'editor-menu');

    editor.insertBefore(editorMenu, editor.firstChild); // prepend menu

    addEventListenerForEditorInputs(); // fields

    // rogue modal, attachements lists

    ModalAttachmentController();

    // snackbar

    var snackbar = document.getElementById('snackbar');




    // populate the modal's color lists

    (function(){

        var colorPicker = modalEditorContent.querySelector('.colorPicker');

        for( var color of colors )
        {
            /*
            <input class="radio blank" type="radio" name="category-color" data-field="color" value="blank" id="hat-color-blank"/>
            <label class="bg-color-blank" for="hat-color-blank">Aucune</label>
            */

            var radio = document.createElement('input');
            radio.id = 'hat-color-'+color;
            radio.name = 'category-color';
            radio.type = 'radio';
            radio.classList.add('radio', color);
            radio.setAttribute('data-field', 'color');
            radio.value = color;

            var label = document.createElement('label');
            label.htmlFor = 'hat-color-'+color;
            label.classList.add('bg-color-'+color);

            colorPicker.appendChild(radio);
            colorPicker.appendChild(label);
        }

    })();


    // populate the categories list

    (function(){

        function populateCategoriesList( categories )
        {
            if( !empty(categories) )
            {
                loop( categories, function( category )
                {
                    var type = category.type;

                    var id = category.id;
                    var title = category.title;
                    var color = category.color;
                    var deleted = category.deleted;

                    if( type == 'mail' )
                    {
                        addNewCategoryItem(id, title, color, deleted);
                    }
                    else if( type == 'line' )
                    {
                        addNewLineItem(id);
                    }
                });
            }
            else
            {
                addPlaceholder(categoryList, 'Il n\'y a aucunes catégories, créer-en !');
            }
        }

        var successHandler = function( categories )
        {
            removeerror();

            loader.style.display = 'none'; // hide loader


            populateCategoriesList(categories);
        }
        
        var errorHandler = function( status )
        {
            error('Impossible de récupérer la liste des catégories', status);
        }


        AjaxSimple({ url: api+'?populateList', successHandler, errorHandler });

    })();



    // create a single categorie

    function onCategoryCreate( event )
    {
        event.preventDefault();

        var title = categoryInput.value;

        if( empty(title) ) return;


        (function(){

            var successHandler = function( category )
            {
                removeerror();

                // remove placeholder, if any

                removePlaceholder(categoryList);

                // clear input

                categoryInput.value = '';

                // add the item

                addNewCategoryItem(category.id, category.title, category.color);
            }
            
            var errorHandler = function( status )
            {
                error('Impossible de créer une nouvelle categorie', status);
            }


            AjaxSimple({ url: api+'?createCategory&categoryTitle='+title, successHandler, errorHandler });

        })();

    }


    // create a new line item

    function onLineCreate( event )
    {
        event.preventDefault();

        (function(){

            var successHandler = function( line )
            {
                removeerror();

                // remove place holder, if any

                removePlaceholder(categoryList);

                // add the line item

                addNewLineItem(line.id);
            }
            
            var errorHandler = function( status )
            {
                error('Impossible de créer une nouvelle ligne', status);
            }


            AjaxSimple({ url: api+'?createLine', successHandler, errorHandler });

        })();
    }


    // click on a category, if success, open the modal with category infos

    function onCategoryClick( event )
    {
        event.preventDefault();

        var categoryId = this.getAttribute('data-id'); // dataset


        (function(){

            var successHandler = function( category )
            {
                removeerror();

                openModal(category);
            }
            
            var errorHandler = function( status )
            {
                error('Impossible de récupérer cette categorie', status);
            }


            AjaxSimple({ url: api+'?getCategory&categoryId='+categoryId, successHandler, errorHandler });

        })();

    }




    function addEventListenerForEditorInputs()
    {
        var title = modalEditorContent.querySelector('[data-field="title"]');

        var content = modalEditorContent.querySelector('[data-field="content"]');

        var subject = modalEditorContent.querySelector('[data-field="subject"]');

        var attachment = modalEditorContent.querySelector('[data-field="attachment"]');

        var colorPicker = modalEditorContent.querySelector('.colorPicker');

        // events

        title.addEventListener('keyup', updateFieldEvent);

        subject.addEventListener('keyup', updateFieldEvent);

        content.addEventListener('input', updateFieldEvent); // TODO: add a paste event

        attachment.addEventListener('change', updateFieldEvent); // dropdown attachements list

        // modal color picker

        delegate(colorPicker, '.radio', 'change', updateFieldEvent);


        // editor part :
        // oh fuuuuuuck... https://github.com/guardian/scribe/blob/master/BROWSERINCONSISTENCIES.md

        // editor insert <br> on return

        if( document.queryCommandSupported('insertBrOnReturn') )
        {
            // firefox

            document.execCommand('insertBrOnReturn', false, true);
        }
        else
        {
            var editorContent = modalEditorContent.querySelector('.editor-content');

            editorContent.addEventListener('keydown', function( event )
            {
                // https://stackoverflow.com/a/20398548

                if( event.keyCode === 13 ) // enter
                {
                    event.preventDefault();

                    // insert 2 br tags (if only one br tag is inserted the cursor won't go to the next line)
                    document.execCommand('insertHTML', false, '<br><br>');
                }

            });

        }


        function updateFieldEvent( event, categoryId )
        {
            var categoryId = modalEditor.getAttribute('data-id');

            var type = this.getAttribute('data-field');


            if( type == 'content' ) // editor
            {
                var value = this.innerHTML;
            }
            else
            {
                var value = this.value;
            }


            handleUpdateField(categoryId, type, value);
        }
    }



    // create/delete timeout, htne update the field

    function handleUpdateField( categoryId, type, value )
    {
        var key = 't'+categoryId+'-'+type; // alternative to the not-so-great multi-level in JS

        // clear previous timer, delay update

        if( isset(timeoutKeyupField[key]) )
        {
            clearTimeout(timeoutKeyupField[key]);

            timeoutKeyupField[key] = null;
        }

        // create the timer

        timeoutKeyupField[key] = setTimeout(updateField, timeoutDuration, categoryId, type, value); // async
    }

    // update a field, don't call it directly, prefer handleUpdateField()

    function updateField( categoryId, type, value )
    {
        var successHandler = function( results )
        {
            removeerror();

            // change item title, color

            if( type == 'title' || type == 'color' )
            {
                changeCategoryItem(categoryId, type, value);
            }
        }

        var errorHandler = function( status )
        {
            error('Impossible de mettre à jour cette catégorie', status);
        }

        var data = {
            field: type,
            value: value
        };

        AjaxSimple({ method: 'POST', url: api+'?updateCategory&categoryId='+categoryId, successHandler, errorHandler, data });
    }




    // open the modal, update the textarea

    function openModal( category )
    {
        var title = modalEditorContent.querySelector('[data-field="title"]');

        var content = modalEditorContent.querySelector('[data-field="content"]');

        var subject = modalEditorContent.querySelector('[data-field="subject"]');

        var attachment = modalEditorContent.querySelector('[data-field="attachment"]');

        var lastmodified = modalEditor.querySelector('.last-modified');


        // modal id

        modalEditor.setAttribute('data-id', category.id);


        // set fields

        title.value = category.title || '';

        content.innerHTML = category.content || '';

        subject.value = category.subject || '';


        // attachements file list

        var attachementFiles = attachment.querySelectorAll('.item-file'); // TODO

        loop(attachementFiles, function( option )
        {
            if( option.value == category.attachment )
            {
                attachment.value = category.attachment;
            }
            else
            {
                option.selected = false;
            }
        });


        // color picker

        var radioColors = modalEditorContent.querySelectorAll('.colorPicker > .radio');

        loop(radioColors, function( radio )
        {
            radio.checked = ( radio.value == category.color && category.color != 'blank' );
        });


        // time

        lastmodified.textContent = prettyDate(category.time);


        // show the modal

        modalEditor.classList.add('open');
    }

    function onModalClose( event )
    {
        event.preventDefault();

        modalEditor.classList.remove('open');
    }


    // click delete/undelete category

    function onCategoryOpenClose( item, event )
    {
        event.stopPropagation();

        var categoryId = item.getAttribute('data-id');

        var deleted = item.getAttribute('data-deleted');


        (function(){

            var successHandler = function( results )
            {
                removeerror();

                // correct the item new attribute

                item.setAttribute('data-deleted', ( deleted == '1' ? '0' : '1' ));
            }

            var errorHandler = function( status )
            {
                if( deleted == '1' )
                {
                    error('Impossible d\'activer cette categorie', status);
                }
                else //if( deleted == '0' )
                {
                    error('Impossible de supprimer cette categorie', status);
                }
            }


            AjaxSimple({ url: api+'?'+( deleted == '1' ? 'openCategory' : 'deleteCategory' )+'&categoryId='+categoryId, successHandler, errorHandler });

        })();

    }

    function onLineDelete( item, event )
    {
        event.stopPropagation();


        var lineId = item.getAttribute('data-id');

        var draggable = findAncestor(item, '.draggable'); // get the draggable parent


        (function(){

            var successHandler = function( results )
            {
                removeerror();

                // delete the draggable element containing the item

                draggable && draggable.remove();
            }

            var errorHandler = function( status )
            {
                error('Impossible de supprimer cette ligne', status);
            }


            AjaxSimple({ url: api+'?deleteLine&lineId='+lineId, successHandler, errorHandler });

        })();
    }

    // add a new category to the list, no ajax

    function addNewCategoryItem( categoryId, title, color, deleted ) // todo: add event delegation
    {
        // wrapper used for dragging

        var itemDrag = document.createElement('div');

        itemDrag.setAttribute('draggable', 'true');

        itemDrag.classList.add('draggable');


        // the real item :

        var item = document.createElement('div');

        item.classList.add('item', 'item-mail');

        item.setAttribute('data-id', categoryId);

        item.setAttribute('data-deleted', deleted || '0');


        var itemTick = document.createElement('div');

        itemTick.classList.add('tick');

        itemTick.textContent = '✔';

        item.appendChild(itemTick);


        var itemTitle = document.createElement('div');

        itemTitle.classList.add('title');

        itemTitle.textContent = title;

        item.appendChild(itemTitle);


        // utils ( right buttons ) on the right on the item :

        var itemUtils = document.createElement('div');

        itemUtils.classList.add('utils');


        var utilColor = document.createElement('span');

        utilColor.classList.add('util', 'util-color');

        utilColor.textContent = '◪';

        if( !empty(color) && color != 'blank' ) // not null, or default
        {
            utilColor.classList.add('bg-color-'+color);
        }

        utilColor.addEventListener('click', function( event )
        {
            // stop the modal

            if( event.target === this ) event.stopPropagation();
        });

        // tooltip color picker :

        attachColorPickerTooltip(utilColor, function( clickEvent )
        {
            clickEvent.stopPropagation();


            var value = this.getAttribute('data-value');

            handleUpdateField(categoryId, 'color', value);
        });

        itemUtils.appendChild(utilColor);


        // delete util

        var utilDelete = document.createElement('span');

        utilDelete.classList.add('util', 'util-delete');

        utilDelete.textContent = '×';

        utilDelete.addEventListener('click', function( event ){ onCategoryOpenClose(item, event); });

        itemUtils.appendChild(utilDelete);


        // add the utils to the item :

        item.appendChild(itemUtils);


        // add the drags events :

        addEventsDragAndDrop(itemDrag);

        // add the simple events :

        item.addEventListener('click', onCategoryClick);

        // add to the main list :

        itemDrag.appendChild(item);

        // append to the list

        categoryList.appendChild(itemDrag);
    }

    // change an element of the item ( title, color )

    function changeCategoryItem( categoryId, type, value )
    {
        // change the item title

        var item = categoryList.querySelector('.item[data-id="'+categoryId+'"]');

        if( item )
        {
            // type specific selector

            var selector = '.'+type;

            if( type == 'color' )
            {
                selector = '.utils > .util-color';
            }

            // change concerned element

            var element = item.querySelector(selector);

            if( element )
            {
                // change prop

                if( type == 'title' )
                {
                    element.textContent = value;
                }
                else if( type == 'color' )
                {
                    assignBgColor(element, value);
                }
            }

        } // if item

    }

    // assign a bg-color to the element

    function assignBgColor( element, color )
    {
        // remove previous color class, if any

        var elementClasses = clone(element.classList);

        loop(elementClasses, function( name, i ) // DOMTokenList
        {
            if( name.startsWith('bg-color-') )
            {
                element.classList.remove(name);
            }
        });

        // set the new class

        if( color != 'blank' )
        {
            element.classList.add('bg-color-'+color);
        }
    }

    // add a new line to the list, no ajax

    function addNewLineItem( id )
    {
        // wrapper used for dragging

        var itemDrag = document.createElement('div');

        itemDrag.setAttribute('draggable', 'true');

        itemDrag.classList.add('draggable');


        // the real item :

        var item = document.createElement('div');

        item.classList.add('item', 'item-line');

        item.setAttribute('data-id', id);


        // utils ( right buttons ) on the right on the item :

        var itemUtils = document.createElement('div');

        itemUtils.classList.add('utils');


        var utilDelete = document.createElement('span');

        utilDelete.classList.add('util', 'util-delete');

        utilDelete.textContent = '×';

        utilDelete.addEventListener('click', function( event ){ onLineDelete(item, event); });

        itemUtils.appendChild(utilDelete);


        // add the utils to the item :

        item.appendChild(itemUtils);


        // add the drags events :

        addEventsDragAndDrop(itemDrag);

        // add to the main list :

        itemDrag.appendChild(item);

        // append to the list

        categoryList.appendChild(itemDrag);
    }


    // attach the tooltip color picker to an element

    function attachColorPickerTooltip( element, clickCallback )
    {
        // create the tool tip

        element.classList.add('tooltip');

        // bubble, on hover

        var bubble = document.createElement('div');

        bubble.classList.add('bubble');

        bubble.appendChild(createColorList());

        element.appendChild(bubble);


        function createColorList()
        {
            var list = document.createElement('div');

            list.classList.add('colorPicker');

            for( var color of colors )
            {
                var div = document.createElement('div');

                div.classList.add('picker', 'bg-color-'+color);

                div.innerText = ( color == 'blank' ? '✕ aucune' : color );

                div.setAttribute('data-value', color);

                // add to the list

                list.appendChild(div);
            }

            // if there is a callable, we delegate it to the list

            if( clickCallback )
            {
                delegate(list, '.picker', 'click', clickCallback);
            }

            return list;
        }
    }



    // DRAG MODULE :

    function addEventsDragAndDrop( element )
    {
        // update categories order after the dragend

        var timeoutReOrder;

        // events

        element.addEventListener('dragstart', dragStart, false);
        element.addEventListener('dragenter', dragEnter, false);
        element.addEventListener('dragover', dragOver, false);
        element.addEventListener('dragleave', dragLeave, false);
        element.addEventListener('drop', dragDrop, false);
        element.addEventListener('dragend', dragEnd, false);


        function dragStart( event )
        {
            this.style.opacity = '0.4';

            currentDragElement = this;

            event.dataTransfer.effectAllowed = 'move';
            event.dataTransfer.setData('text/html', this.innerHTML);
        };

        function dragEnter( event )
        {
            this.classList.add('over');
        }

        function dragLeave( event )
        {
            event.stopPropagation();

            this.classList.remove('over');
        }

        function dragOver( event )
        {
            event.preventDefault();

            event.dataTransfer.dropEffect = 'move';

            return false;
        }

        function dragDrop( event )
        {
            if( currentDragElement != this )
            {
                //currentDragElement.innerHTML = this.innerHTML;

                //this.innerHTML = event.dataTransfer.getData('text/html');

                swapElements(currentDragElement, this);


                // clear previous timer, delay update

                if( isset(timeoutReOrder) )
                {
                    clearTimeout(timeoutReOrder);

                    timeoutReOrder = null;
                }

                // create the timer

                timeoutReOrder = setTimeout(updateCategoriesOrderAjax, timeoutDuration); // async
            }

            return false;
        }

        function dragEnd( event )
        {
            var items = categoryList.querySelectorAll('.draggable');

            loop(items, function( item )
            {
                // remove hover class, when drag-hover other items
            
                item.classList.remove('over');
            });

            this.style.opacity = '1';
        }

        function updateCategoriesOrderAjax()
        {

            var items = categoryList.querySelectorAll('.item');

            if( !empty(items) ) // TODO NODELIST
            {
                var orders = {};

                var position = 0;

                loop(items, function( item )
                {
                    var id = parseInt(item.getAttribute('data-id'));

                    orders[id] = ++position;
                });


                (function(){

                    var successHandler = function( results )
                    {
                        removeerror();
                    }
                    
                    var errorHandler = function( status )
                    {
                        error('Impossible de changer l\'ordre des catégories', status);
                    }


                    AjaxSimple({ method: 'POST', url: api+'?updateOrder', successHandler, errorHandler, data: orders });

                })();

            } // !empty items

        }
    

    } // addEventsDragAndDrop







    // rogue modal, attachements lists

    function ModalAttachmentController()
    {
        // launch button

        var attachmentButton = document.getElementById('attachment-button');

        attachmentButton.addEventListener('click', onButtonClick);

        // modal content

        var modalAttachment = document.getElementById('modalAttachment');

        var modalAttachmentContent = modalAttachment.querySelector('.modal-content');

        var modalAttachmentClose = modalAttachment.querySelector('.modal-close');

        modalAttachmentClose.addEventListener('click', onModalClose);

        modalAttachment.addEventListener('click', function( event ) // click outsie modal-dialog ( window )
        {
            if( event.target == this ) onModalClose(event);
        });

        // list of files

        var attachmentsList = document.getElementById('attachments-list');

        delegate(attachmentsList, '.item .utils .util-delete', 'click', onItemFileDelete);

        // form upload

        var attachmentUploadForm = document.getElementById('attachment-upload-form');

        var uploadingLoader = modalAttachmentContent.querySelector('.uploading-loader');

        addEventsForUploadForm(attachmentUploadForm);



        // populate the modal's file lists

        (function(){


            function populateFilesList( files )
            {
                if( !empty(files) )
                {
                    loop(files, function( file )
                    {
                        addNewFileItem(file.name);
                    });
                }
                else
                {
                    addPlaceholder(attachmentsList, 'Il n\'y a aucun fichiers, ajouter-en !');
                }
            }

            var successHandler = function( files )
            {
                removeerror();

                populateFilesList(files);
            }
            
            var errorHandler = function( status )
            {
                error('Impossible de récupérer la liste des fichiers', status);
            }


            AjaxSimple({ url: api+'?populateFileList', successHandler, errorHandler });

        })();


        function addNewFileItem( fileName )
        {
            // name, type, size

            var item = document.createElement('div');

            item.classList.add('item', 'item-file');

            item.setAttribute('data-value', fileName);

            item.innerText = fileName;

            // utils

            var itemUtils = document.createElement('div');

            itemUtils.classList.add('utils');

            // delete util

            var utilDelete = document.createElement('span');

            utilDelete.classList.add('util', 'util-delete');

            utilDelete.innerText = '×';

            // add to utils

            itemUtils.appendChild(utilDelete);

            item.appendChild(itemUtils);

            // append to the list

            attachmentsList.appendChild(item);


            // rogue effect, also add an option to the dropdown of the modal editor :

            addEditorAttachmentItem(fileName);
        }

        function removeFileItem( fileName )
        {
            var item = modalAttachmentContent.querySelector('.item[data-value="'+fileName+'"]');

            if( item )
            {
                item.remove();
            }


            // rogue effect, also remove the item from the editor modal dropdown

            removeEditorAttachmentItem(fileName);
        }

        // event when deleting a file

        function onItemFileDelete( event )
        {
            event.preventDefault();


            if( !confirm('Supprimer ce fichier ?') ) return;


            // seek the item file

            var item = findAncestor(this, '.item');

            if( item )
            {
                var fileName = item.getAttribute('data-value');

                deleteFile(fileName);
            }


            // confirm the deletion of the file

            function deleteFile( fileName )
            {
                var errorHandler = function( status )
                {
                    error('Impossible de supprimer ce fichier', status);
                }

                var successHandler = function( result )
                {
                    removeerror();


                    // if there is an error

                    if( !empty(result.error) )
                    {
                        errorHandler(result.error);
                    }
                    else
                    {
                        // remove item from the list

                        removeFileItem(fileName);


                        // add a placeholder, if not files

                        var items = attachmentsList.querySelectorAll('.item');

                        if( items.length == 0 ) // TODO NODELIST
                        {
                            addPlaceholder(attachmentsList, 'Il n\'y a aucun fichiers, ajouter-en !');
                        }
                    }
                }


                AjaxSimple({ url: api+'?fileDelete&fileName='+fileName, successHandler, errorHandler });

            }

        }



        // events for the forms inputs, submit

        function addEventsForUploadForm( form )
        {
            var input = form.querySelector('.upload-files-input');

            var label = form.querySelector('.upload-files-label');

            var button = form.querySelector('.form-submit');

            input.value = ''; // cache reset


            // events

            form.addEventListener('submit', onFormSubmit);

            input.addEventListener('change', onInputChange);



            // new button upload

            function onInputChange( event )
            {
                var text = '%d fichiers sélectionnés';

                var fileName = '';


                if( this.files && this.files.length > 1 )
                {
                    fileName = text.replace('%d', this.files.length);
                }
                else
                {
                    fileName = event.target.value.split('\\').pop();
                }
                    
                if( fileName )
                {
                    label.querySelector('span').innerText = fileName;
                }

                // auto submit form
                // form.querySelector('[type="submit"]').click();
            }


            // form upload submit

            function onFormSubmit( event )
            {
                event.preventDefault();


                // only upload when set

                if( empty(input.value) ) return;


                // preventing the duplicate submissions if the current one is in progress

                if( this.classList.contains('is-uploading' )) return false;


                // indicate we're uploading something

                form.classList.add('is-uploading');


                // gathering the form data

                var ajaxData = new FormData(this);

                validateFilesUpload(ajaxData);

                // for (var pair of ajaxData.entries()) {
                //     console.log(pair[0]);
                //     console.log(pair[1]); 
                // }


                // we can re-upload files

                this.classList.remove('is-uploading');


                input.value = ''; // cache reset

                label.querySelector('span').innerText = 'Ajouter des fichiers...';
            }


            function validateFilesUpload( data )
            {
                // show the loader

                uploadingLoader.classList.add('show');


                var errorHandler = function( status )
                {
                    error('Impossible de télécharger le(s) fichier(s)', status);
                }

                var successHandler = function( result )
                {
                    removeerror();

                    // hide the loader

                    uploadingLoader.classList.remove('show');


                    // if errors :

                    if( !empty(result.error) )
                    {
                        errorHandler(result.error);
                    }
                    else if( !empty(result.files) )
                    {

                        // remove placeholder, if any

                        removePlaceholder(attachmentsList);

                        // add files to the list :

                        loop(result.files, function( file )
                        {
                            // only add the file item, if not exist already :

                            var item = modalAttachmentContent.querySelector('.item[data-value="'+file.name+'"]');

                            if( !item )
                            {
                                addNewFileItem(file.name);
                            }
                        });
                    }
                }

                // var progressHandler = function( percentComplete ) // too fast
                // {
                //     if( percentComplete != 'unknown-size' )
                //     {
                //         uploadingLoader.style.width = percentComplete + '%';
                //     }
                // }


                AjaxSimple({ method: 'POST', url: api+'?fileUpload', successHandler, errorHandler, data, contentType: false, stringify: 'text' });
            }


        } // add event form



        // add an option to the dropdown of the editor modal

        function addEditorAttachmentItem( fileName )
        {
            var attachment = modalEditorContent.querySelector('[data-field="attachment"]');


            var item = document.createElement('option');

            item.classList.add('item', 'item-file');

            item.value = fileName;

            item.innerText = fileName;


            // add item to the list

            attachment.appendChild(item);
        }

        function removeEditorAttachmentItem( fileName )
        {
            var attachment = modalEditorContent.querySelector('[data-field="attachment"]');


            // remove item from the list

            var item = attachment.querySelector('.item[value="'+fileName+'"]');

            if( item )
            {
                item.remove();
            }
        }


        // main button

        function onButtonClick( event )
        {
            event.preventDefault();

            openModal();
        }


        function openModal()
        {
            // show the modal

            modalAttachment.classList.add('open');
        }

        function onModalClose( event )
        {
            event.preventDefault();

            modalAttachment.classList.remove('open');
        }


    } //ModalAttachmentController

















    // add a temp snackbar notification

    function notification( text )
    {
        snackbar.innerText = text;

        snackbar.classList.add('show');

        setTimeout(function()
        {
            snackbar.classList.remove('show');

        }, 3000);
    }

    // display an error message ( modal, page )

    function error( text, status )
    {
        function stackTrace()
        {
            return ( new Error().stack || '' );
        }

        var div = document.getElementById('error');

        var emessage = div.querySelector('.message');

        var estatus = div.querySelector('.status');

        var estack = div.querySelector('.stack');

        emessage.innerText = 'Erreur: "' + text + '", essayez de recharger la page.';

        if( !empty(status) )
        {
            estatus.innerText = 'Code: ' + status;
        }

        // show / hide stack, quick-dirty function

        estatus.onclick = function( event )
        {
            estack.classList.toggle('show');
        };


        estack.innerText = stackTrace();

        // show the message

        div.classList.add('show');
    }

    // remove old error of the page

    function removeerror()
    {
        var message = document.getElementById('error');

        message.classList.remove('show');
    }

    // placeholder, when there is not items to display

    function addPlaceholder( container, text )
    {
        var placeholder = document.createElement('div');

        placeholder.classList.add('placeholder');

        // smiley top

        var smiley = document.createElement('div');

        smiley.classList.add('smiley');

        smiley.innerText = '☺';

        placeholder.appendChild(smiley);

        // description, bottom

        var description = document.createElement('div');

        description.classList.add('description');

        description.innerHTML = text;

        placeholder.appendChild(description);

        // add to the element :

        container.appendChild(placeholder);
    }

    function removePlaceholder( container )
    {
        var placeholder = container.querySelector('.placeholder');

        if( placeholder ) placeholder.remove();
    }



}); // window.load








function createEditorMenu( options )
{
    var options = [
        [
            // remove formatting TODO
            { title: 'X', action: 'removeFormat' },

            //B U I
            { title: 'B', action: 'bold'      },
            { title: 'I', action: 'italic'    },
            { title: 'U', action: 'underline' },

            // alignment
            // { title: '⚟', action: 'justifyleft' },
            // { title: '☰', action: 'justifycenter' },
            // { title: '⚞', action: 'justifyright' },

            //list
            { title: 'UL', action: 'insertUnorderedList' },
            { title: 'OL', action: 'insertOrderedList'   },

            // heading - no chrome
            { title: 'H1', action: 'formatBlock', value: 'h1' },
            { title: 'H2', action: 'formatBlock', value: 'h2' },
            { title: 'H3', action: 'formatBlock', value: 'h3' },
            { title: 'H4', action: 'formatBlock', value: 'h4' },

            //links
            { title: 'Lien', action: 'createLinkPrompt' },
        ],
        [
            //others
            { title: 'Prospect',        action: 'fusion', value: 'prospect' },
            { title: 'Date JJ/MM/AAAA', action: 'fusion', value: 'dateJJMMAAAA' },

            { title: 'Lien Netty',          action: 'createLink', value: 'https://www.netty.fr/' },
            { title: 'Netty/creation site', action: 'createLink', value: 'https://www.netty.fr/creation-site-immobilier' },
            { title: 'Netty/logiciel',      action: 'createLink', value: 'https://www.netty.fr/logiciel-immobilier' }

            
        ]
    ];

    var menu = document.createElement('div');

    menu.classList.add('menu');

    // delegate events to buttons

    delegate(menu, '.button', 'click', onActionClick);

    // add buttons to menu :

    loop(options, function( level )
    {
        var group = document.createElement('div');

        group.classList.add('group');


        loop(level, function( option )
        {
            var button = document.createElement('button');

            button.classList.add('button')

            button.type = 'button';

            button.textContent = option.title;

            button.setAttribute('data-action', option.action);

            // set the action :

            if( option.value ) 
            {
                button.setAttribute('data-value', option.value);
            }

            // add to group :

            group.appendChild(button); 
        });

        // add group to menu

        menu.appendChild(group);
    });


    // return the menu
    
    return menu;


    function onActionClick( event )
    {
        var command = this.getAttribute('data-action');
        var value = this.getAttribute('data-value');


        if( command == 'createLinkPrompt' )
        {
            command = 'createLink';

            if( empty(value = prompt('Adresse URL :', 'http://')) )
            {
                return false;
            }
        }
        else if( command == 'fusion' ) // TODO: bugs on return key / formatting
        {
            command = 'insertHTML';

            value = ' <span class="fusion" data-fusion="'+value+'" contenteditable="false">'+this.textContent+'</span> ';
        }



        document.execCommand(command, false, value || null);
    }


}


// PHP : <span[^>]*?data-fusion="(\w+)".*?>.*?</span>
