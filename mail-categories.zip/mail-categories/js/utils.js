"use strict";

// debug

function l(t){console.log(t);}


//https://github.com/lodash/lodash/





// types types :

function isArray( item )
{
    return Array.isArray(item);
}

function isObject( item ) // array is also an object
{
    return ( item && typeof item === 'object' );
}

function isString( item )
{
    return ( item && typeof item === 'string' );
}


// utils :

function empty( value )
{
    return ( isArray(value) && value.length < 1 ) || ( [undefined, null, false, 0, '', '0'].indexOf(value) > -1 );
}

function isset( value )
{
    return ( [undefined, null].indexOf(value) < 0 );
}

function loop( elements, callback ) //for..in,of
{
    //for( var i = 0, l = elements.length; i < l; i++ ) callback(elements[i], i);

    var keys = Object.keys(elements);

    for( var key in keys ) callback(elements[key], key);
}


// delegate events

function delegate( parent, target, eventType, callback )
{
    if( isString(parent) )
    {
        var parent = document.querySelector(parent);
    }

    parent.addEventListener(eventType, function( event )
    {
        var element = event.target;

        if( (element.matches || element.matchesSelector).call(element, target) )
        {
            callback.call(element, event);
        }
    });
}

function live( selector, eventType, callback )
{
    delegate(document, selector, eventType, callback);
}


// recursive deep copy of an object, no references used

function fusion( first )
{
    var hasOwnProperty = Object.hasOwnProperty;


    // check if the first is an array, then mix the rest

    var extended = ( isArray(first) ? [] : {} );

    function merge( target, args )
    {
        for( var i = 0, l = args.length; i < l; i++ ) //0=target
        {
            var source = args[i];

            for( var key in source )
            {
                if( isObject(source[key]) ) // array is also an object
                {
                    target[key] = ( isArray(source[key]) ? [] : {} );

                    merge(target[key], [ source[key] ]);
                }
                else if( hasOwnProperty.call(source, key) )
                {
                    target[key] = source[key];
                }
            }
        }

        return target;
    }

    // merging

    //var slice = [].slice;
    //return merge(extended, slice.call(arguments, 1));

    return merge(extended, arguments);
}

// clone an object

function clone( target )
{
    return fusion({}, target);
}


// find the ancestor of an element || null

function findAncestor( el, selector ) // element.closest polyfill
{
    while(  (el = el.parentElement) && !( (el.matches || el.matchesSelector).call(el, selector) )  );

    return el;
}


// swap elements https://stackoverflow.com/a/10717422

function swapElements( obj1, obj2 )
{
    // save the location of obj2

    var parent2 = obj2.parentNode;
    var next2 = obj2.nextSibling;


    // special case for obj1 is the next sibling of obj2

    if( next2 === obj1 )
    {
        // just put obj1 before obj2

        parent2.insertBefore(obj1, obj2);
    }
    else
    {
        // insert obj2 right before obj1

        obj1.parentNode.insertBefore(obj2, obj1);

        // now insert obj1 where obj2 was

        if( next2 )
        {
            // if there was an element after obj2, then insert obj1 right before that

            parent2.insertBefore(obj1, next2);
        }
        else
        {
            // otherwise, just append as last child

            parent2.appendChild(obj1);
        }
    }
}




// function String.prototype.format = function()
// {
//     var args = arguments;

//     return this.replace(/{(\d+)}/g, function( match, number )
//     {
//         return ( typeof args[number] != 'undefined' ? args[number] : match );
//     });
// }


// function strip( number ) // binary float : 10 - 9.1 == 0.9000000000000004
// {
//     return +(parseFloat(number).toPrecision(12));

//     // + toFixed()
// }






function prettyDate( date )
{
    var pretty = {

        default: '---',

        prefixAgo: 'il y a',
        prefixFromNow: 'd\'ici',
        prefixDate: 'le',

        translateDateWhen: 60*60*24*31*5, // convert to date when > 5 months in seconds

        wordSeparator: ' ',

        seconds: 'moins d\'une minute',

        minute: 'environ une minute',
        minutes: 'environ %d minutes',

        hour: 'environ une heure',
        hours: 'environ %d heures',

        day: 'environ un jour',
        days: 'environ %d jours',

        week: 'environ une semaine',
        weeks: 'environ %d semaines',

        month: 'environ un mois',
        months: 'environ %d mois',

        year: 'un an',
        years: '%d ans',

        dateMonths: ['janvier', 'février', 'mars', 'avril', 'mai', 'juin', 'juillet', 'août', 'septembre', 'octobre', 'novembre', 'décembre']
    };


    function isValid( date )
    {
        return ( !isNaN(date.getTime()) );
    }

    function substitute( string, number ) 
    {
        number = Math.floor(number); //

        return string.replace('%d', number);
    }

    function translateDate( date )
    {
        var day = date.getDate().toString();

        day = ( day.length > 1 ? day : '0' + day );

        var month = pretty.dateMonths[date.getMonth()];

        var year = date.getFullYear();


        return ([pretty.prefixDate, day, month, year].join(pretty.wordSeparator));
    }

    function translateWords( distance, isFuture )
    {
        var seconds = distance / 1000;
        var minutes = seconds / 60;
        var hours = minutes / 60;
        var days = hours / 24;
        var weeks = days / 7;
        var months = days / 31;
        var years = days / 365;

        var words = (

            seconds < 60 && substitute(pretty.seconds, seconds) || // almost now

            minutes < 2  && substitute(pretty.minute, 1)        ||
            minutes < 60 && substitute(pretty.minutes, minutes) ||

            hours < 2  && substitute(pretty.hour, 1)      ||
            hours < 24 && substitute(pretty.hours, hours) ||

            days < 2 && substitute(pretty.day, 1)     ||
            days < 7 && substitute(pretty.days, days) ||

            weeks  < 2 && substitute(pretty.week, 1)      ||
            months < 1 && substitute(pretty.weeks, weeks) ||

            months < 2  && substitute(pretty.month, 1)       ||
            months < 12 && substitute(pretty.months, months) ||

            years < 2 && substitute(pretty.year, 1) || substitute(pretty.years, years)
        );

        if( !words ) return pretty.default;


        return ( [(isFuture ? pretty.prefixFromNow : pretty.prefixAgo), words].join(pretty.wordSeparator) );
    }

    // parsing :

    var date = (date instanceof Date) ? date : new Date(date);

    if( !isValid(date) ) return pretty.default; // not a valid date


    var diff = ( (new Date()).getTime() - date.getTime() );

    var isFuture = ( diff < 0 ); // in the future

    var distance = Math.abs(diff); // millis


    // translate distance to words or date

    if( !pretty.translateDateWhen || distance < pretty.translateDateWhen*1000 )
    {
        return translateWords(distance, isFuture);
    }
    else
    {
        return translateDate(date);
    }
}

