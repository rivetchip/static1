


function AjaxSimple( params ) // method, url, datas, params   // TODO: form data
{
    var defaults = {
        method: 'GET',
        contentType: true,

        successHandler: null,
        errorHandler: null,
        progressHandler: null,

        parse: null,
        stringify: null,

        data: null
    };

    // options :

    //var params = ( arguments.length > 2 ? arguments[arguments.length - 1] : [] );

    var o = extend({}, defaults, params);

    // main :

    var x = new XMLHttpRequest();

    x.open(o.method, o.url, true);

    //x.withCredentials = true;

    x.onerror = xhrError;
    x.onabort = xhrAbort;
    x.ontimeout = xhrTimeout;

    x.setRequestHeader('X-Requested-With', 'XMLHttpRequest');

    x.onreadystatechange = xhrReadyStateChange;


    if( o.data && typeof o.data !== 'undefined' ) // with datas
    {
        if( o.contentType ) // set the cotnent type if any
        {
            // application/x-www-form-urlencoded
            // multipart/form-data

            x.setRequestHeader('Content-Type', 'application/json;charset=utf-8');
        }

        x.upload.onprogress = xhrProgess;

        x.send(stringify(o.data));
    }
    else // normal GET
    {
        x.onprogress = xhrProgess;

        x.send();
    }


    // private methods :

    function parse( response )
    {
        if( o.parse === 'text' ) return response;

        return ( o.parse && o.parse(response) || JSON.parse(response) );

        //return ( o.parse ? o.parse(response) : JSON.parse(response) );
    }
    function stringify( data )
    {
        if( o.stringify === 'text' ) return data;

        return ( o.stringify && o.stringify(data) || JSON.stringify(data) );
    }


    function successHandler( response )
    {
        o.successHandler && o.successHandler(response);
    }

    function errorHandler( response )
    {
        o.errorHandler && o.errorHandler(response);
    }

    function progressHandler( percent ) // download & upload
    {
        o.progressHandler && o.progressHandler(percent);
    }

    function xhrReadyStateChange()
    {
        if( this.readyState === this.DONE ) // DONE:4
        {
            var status = this.status;

            if( status >= 200 && status < 300 ) // OK
            {
                try
                {
                    var response = parse(this.responseText);

                    successHandler(response);
                }
                catch( e )
                {
                    errorHandler('ajax-exception');

                    console.log(e); // FIXME
                }
            }
            else
            {
                errorHandler('http');
            }
        }
    }

    function xhrProgess( event )
    {
        if( event.lengthComputable )
        {
            var percentComplete = Math.round(event.loaded * 100 / event.total);

            progressHandler(percentComplete);
        }
        else
        {
            progressHandler('unknown-size');
        }
    }

    function xhrTimeout( event )
    {
        errorHandler('timeout');
    }

    function xhrError( event )
    {
        errorHandler('error'); // TODO: if abort : called readystatechange then error
    }

    function xhrAbort( event )
    {
        errorHandler('abort');
    }


    //extend, polyfill for Object.assign

    function extend( target )
    {
        for( var i = 1; i < arguments.length; i++ ) // for..of todo
        {
            var source = arguments[i];

            for( var key in source )
            {
                if( Object.prototype.hasOwnProperty.call(source, key) )
                {
                    target[key] = source[key];
                }
            }
        }

        return target;
    }

}


// application/x-www-form-urlencoded
// multipart/form-data








// legacy ajax function
/*
function AjaxSimple( method, url, successHandler, errorHandler, data, progressHandler )
{

    // private methods :

    function parse( response )
    {
        return JSON.parse( response );
    }

    function stringify( data )
    {
        return JSON.stringify( data );
    }

    function xhrReadyStateChange()
    {
        if ( this.readyState === this.DONE ) // DONE:4
        {
            var status = this.status;

            if ( status >= 200 && status < 300 ) // OK
            {
                try
                {
                    var response = parse(this.responseText);

                    successHandler && successHandler(response);
                }
                catch( e )
                {
                    errorHandler && errorHandler('ajax-exception', e);

                    // console.log(e);
                }
            }
            else
            {
                errorHandler && errorHandler('http');
            }
        }
    }

    function xhrProgess( event )
    {
        if ( event.lengthComputable )
        {
            var percentComplete = Math.round(event.loaded * 100 / event.total);

            progressHandler && progressHandler(percentComplete);
        }
        else
        {
            progressHandler && progressHandler('unknown-size');
        }
    }

    function xhrTimeout( event )
    {
        errorHandler && errorHandler('timeout');
    }

    function xhrError( event )
    {
        errorHandler && errorHandler('error');
    }

    function xhrAbort( event )
    {
        errorHandler && errorHandler('abort');
    }

    // main :

    var isForm = false;

    var x = new XMLHttpRequest();

    x.open(method, url, true);

    //x.withCredentials = true;

    x.onerror = xhrError;
    x.onabort = xhrAbort;
    x.ontimeout = xhrTimeout;

    x.setRequestHeader('X-Requested-With', 'XMLHttpRequest');

    x.onreadystatechange = xhrReadyStateChange;


    if( data && typeof data !== 'undefined' ) // with datas
    {
        // x.setRequestHeader('Content-Type', 'application/json;charset=utf-8'); // form data

        x.upload.onprogress = xhrProgess;

        x.send(stringify(data));

    }
    else // normal GET
    {
        x.onprogress = xhrProgess;

        x.send();
    }

}
*/



